# HTML5 Development

Download the HTMLStarter Template

Extract it and load it to your Editor

These are just starter files , just follow my classes for complete HTML files.
